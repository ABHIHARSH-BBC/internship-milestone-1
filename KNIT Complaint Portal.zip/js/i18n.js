const translations = {
  en: {
    // Nav
    navHome: "Home",
    navAbout: "About",
    navHelpline: "Helpline",
    navDashboard: "Dashboard",
    navLogin: "Login",
    navRegister: "Register",
    navLogout: "Logout",
    
    // Hero
    heroBadge: "Live Portal",
    heroTitle1: "KNIT Sultanpur",
    heroTitle2: "Complaint Portal",
    heroDesc: "A unified platform for students, faculty, and administration to register, track, and resolve complaints in real-time. Your voice matters.",
    heroBtnRegister: "Register Now",
    heroBtnTrack: "Track Complaint",
    
    // Hero Card
    heroCardTitle: "Complaint Dashboard",
    heroCardSub: "Real-time overview",
    statPending: "Pending",
    statResolved: "Resolved",
    statInProgress: "In Progress",
    recentTitle: "Recent Complaints",
    
    // Features
    featureTag: "Features",
    featureTitle: "Why Use Our Portal?",
    featureDesc: "Streamlined complaint management system designed for the KNIT community",
    
    feat1Title: "Real-Time Tracking",
    feat1Desc: "Track your complaint status in real-time. Get instant notifications when your complaint is updated or resolved.",
    
    feat2Title: "Secure & Private",
    feat2Desc: "Your data is encrypted and secure. Only authorized personnel can access complaint details.",
    
    feat3Title: "Multi-Language",
    feat3Desc: "Use the portal in English or Hindi. Language selector available on every page for your convenience.",
    
    feat4Title: "Role-Based Access",
    feat4Desc: "Separate dashboards for Students, Faculty, and Director. Each role has specific permissions and views.",
    
    feat5Title: "Direct to Authority",
    feat5Desc: "Complaints reach directly to the concerned authority. No middleman, faster resolution.",
    
    feat6Title: "24/7 Available",
    feat6Desc: "Register complaints anytime, anywhere. The portal is available round the clock.",
    
    // Footer
    footerDesc: "Kamla Nehru Institute of Technology, Sultanpur - Official Complaint Management Portal",
    footerQuickLinks: "Quick Links",
    footerDepartments: "Departments",
    footerContact: "Contact",
    
    // Auth
    loginTitle: "Welcome Back",
    loginSub: "Sign in to your account",
    registerTitle: "Create Account",
    registerSub: "Join the complaint portal",
    
    email: "Email Address",
    password: "Password",
    confirmPassword: "Confirm Password",
    fullName: "Full Name",
    phoneNumber: "Phone Number",
    rollNumber: "Roll / Employee ID",
    department: "Department",
    year: "Year / Semester",
    hostel: "Hostel (if applicable)",
    
    roleStudent: "Student",
    roleFaculty: "Faculty",
    roleDirector: "Director",
    
    selectRole: "Select Your Role",
    rememberMe: "Remember me",
    forgotPass: "Forgot Password?",
    noAccount: "Don't have an account?",
    haveAccount: "Already have an account?",
    signUp: "Sign Up",
    signIn: "Sign In",
    registerBtn: "Create Account",
    
    // Dashboard
    welcome: "Welcome back,",
    myComplaints: "My Complaints",
    newComplaint: "New Complaint",
    complaintHistory: "Complaint History",
    
    complaintSubject: "Subject",
    complaintCategory: "Category",
    complaintDesc: "Description",
    complaintPriority: "Priority",
    complaintDate: "Date",
    complaintStatus: "Status",
    complaintActions: "Actions",
    
    catAcademic: "Academic",
    catInfra: "Infrastructure",
    catHostel: "Hostel",
    catMess: "Mess & Canteen",
    catLibrary: "Library",
    catFinance: "Finance & Fee",
    catExam: "Examination",
    catPlacement: "Placement",
    catOther: "Other",
    
    priorityHigh: "High",
    priorityMedium: "Medium",
    priorityLow: "Low",
    
    statusPending: "Pending",
    statusInProgress: "In Progress",
    statusResolved: "Resolved",
    statusRejected: "Rejected",
    
    submitComplaint: "Submit Complaint",
    cancel: "Cancel",
    viewDetails: "View Details",
    
    // Helpline
    helplineTitle: "Helpline Numbers",
    helplineSub: "Important contact numbers for KNIT Sultanpur",
    searchPlaceholder: "Search by name or designation...",
    
    // Director
    allComplaints: "All Complaints",
    manageComplaints: "Manage & Resolve",
    forward: "Forward",
    resolve: "Resolve",
    reject: "Reject",
    
    // General
    loading: "Loading...",
    noResults: "No results found",
    save: "Save",
    edit: "Edit",
    delete: "Delete",
    close: "Close",
    viewAll: "View All",
    poweredBy: "Powered by",
    
    // Months
    months: ["January","February","March","April","May","June","July","August","September","October","November","December"]
  },
  
  hi: {
    // Nav
    navHome: "होम",
    navAbout: "परिचय",
    navHelpline: "हेल्पलाइन",
    navDashboard: "डैशबोर्ड",
    navLogin: "लॉगिन",
    navRegister: "रजिस्टर",
    navLogout: "लॉगआउट",
    
    // Hero
    heroBadge: "लाइव पोर्टल",
    heroTitle1: "केएनआईटी सुल्तानपुर",
    heroTitle2: "शिकायत पोर्टल",
    heroDesc: "छात्रों, संकाय और प्रशासन के लिए शिकायत दर्ज करने, ट्रैक करने और हल करने का एक एकीकृत मंच। आपकी आवाज़ मायने रखती है।",
    heroBtnRegister: "अभी रजिस्टर करें",
    heroBtnTrack: "शिकायत ट्रैक करें",
    
    // Hero Card
    heroCardTitle: "शिकायत डैशबोर्ड",
    heroCardSub: "रियल-टाइम अवलोकन",
    statPending: "लंबित",
    statResolved: "हल हो गया",
    statInProgress: "प्रगति में",
    recentTitle: "हाल की शिकायतें",
    
    // Features
    featureTag: "विशेषताएँ",
    featureTitle: "हमारे पोर्टल का उपयोग क्यों करें?",
    featureDesc: "केएनआईटी समुदाय के लिए डिज़ाइन किया गया सुव्यवस्थित शिकायत प्रबंधन प्रणाली",
    
    feat1Title: "रियल-टाइम ट्रैकिंग",
    feat1Desc: "अपनी शिकायत की स्थिति को रियल-टाइम में ट्रैक करें। जब आपकी शिकायत अपडेट या हल हो जाए तो तुरंत सूचना प्राप्त करें।",
    
    feat2Title: "सुरक्षित और निजी",
    feat2Desc: "आपका डेटा एन्क्रिप्टेड और सुरक्षित है। केवल अधिकृत कर्मचारी ही शिकायत विवरण देख सकते हैं।",
    
    feat3Title: "बहु-भाषा",
    feat3Desc: "पोर्टल का उपयोग अंग्रेजी या हिंदी में करें। आपकी सुविधा के लिए हर पृष्ठ पर भाषा चयनक उपलब्ध है।",
    
    feat4Title: "भूमिका-आधारित पहुँच",
    feat4Desc: "छात्रों, संकाय और निदेशक के लिए अलग-अलग डैशबोर्ड। प्रत्येक भूमिका की विशिष्ट अनुमतियाँ और दृश्य हैं।",
    
    feat5Title: "प्राधिकरण तक सीधे",
    feat5Desc: "शिकायतें सीधे संबंधित प्राधिकरण तक पहुँचती हैं। कोई बिचौलिया नहीं, तेज़ समाधान।",
    
    feat6Title: "24/7 उपलब्ध",
    feat6Desc: "कभी भी, कहीं भी शिकायत दर्ज करें। पोर्टल चौबीसों घंटे उपलब्ध है।",
    
    // Footer
    footerDesc: "कामला नेहरू संस्थान तकनीकी, सुल्तानपुर - आधिकारिक शिकायत प्रबंधन पोर्टल",
    footerQuickLinks: "त्वरित लिंक",
    footerDepartments: "विभाग",
    footerContact: "संपर्क",
    
    // Auth
    loginTitle: "वापसी पर स्वागत",
    loginSub: "अपने खाते में साइन इन करें",
    registerTitle: "खाता बनाएं",
    registerSub: "शिकायत पोर्टल से जुड़ें",
    
    email: "ईमेल पता",
    password: "पासवर्ड",
    confirmPassword: "पासवर्ड की पुष्टि करें",
    fullName: "पूरा नाम",
    phoneNumber: "फ़ोन नंबर",
    rollNumber: "रोल / कर्मचारी आईडी",
    department: "विभाग",
    year: "वर्ष / सेमेस्टर",
    hostel: "छात्रावास (यदि लागू हो)",
    
    roleStudent: "छात्र",
    roleFaculty: "संकाय",
    roleDirector: "निदेशक",
    
    selectRole: "अपनी भूमिका चुनें",
    rememberMe: "मुझे याद रखें",
    forgotPass: "पासवर्ड भूल गए?",
    noAccount: "खाता नहीं है?",
    haveAccount: "पहले से खाता है?",
    signUp: "साइन अप",
    signIn: "साइन इन",
    registerBtn: "खाता बनाएं",
    
    // Dashboard
    welcome: "वापसी पर स्वागत है,",
    myComplaints: "मेरी शिकायतें",
    newComplaint: "नई शिकायत",
    complaintHistory: "शिकायत इतिहास",
    
    complaintSubject: "विषय",
    complaintCategory: "श्रेणी",
    complaintDesc: "विवरण",
    complaintPriority: "प्राथमिकता",
    complaintDate: "तिथि",
    complaintStatus: "स्थिति",
    complaintActions: "कार्य",
    
    catAcademic: "शैक्षणिक",
    catInfra: "बुनियादी ढांचा",
    catHostel: "छात्रावास",
    catMess: "मेस और कैंटीन",
    catLibrary: "पुस्तकालय",
    catFinance: "वित्त और शुल्क",
    catExam: "परीक्षा",
    catPlacement: "प्लेसमेंट",
    catOther: "अन्य",
    
    priorityHigh: "उच्च",
    priorityMedium: "मध्यम",
    priorityLow: "निम्न",
    
    statusPending: "लंबित",
    statusInProgress: "प्रगति में",
    statusResolved: "हल",
    statusRejected: "अस्वीकृत",
    
    submitComplaint: "शिकायत दर्ज करें",
    cancel: "रद्द करें",
    viewDetails: "विवरण देखें",
    
    // Helpline
    helplineTitle: "हेल्पलाइन नंबर",
    helplineSub: "केएनआईटी सुल्तानपुर के लिए महत्वपूर्ण संपर्क नंबर",
    searchPlaceholder: "नाम या पदनाम से खोजें...",
    
    // Director
    allComplaints: "सभी शिकायतें",
    manageComplaints: "प्रबंधन और समाधान",
    forward: "अग्रेषित करें",
    resolve: "हल करें",
    reject: "अस्वीकार करें",
    
    // General
    loading: "लोड हो रहा है...",
    noResults: "कोई परिणाम नहीं मिला",
    save: "सहेजें",
    edit: "संपादित करें",
    delete: "हटाएं",
    close: "बंद करें",
    viewAll: "सभी देखें",
    poweredBy: "द्वारा संचालित",
    
    months: ["जनवरी","फरवरी","मार्च","अप्रैल","मई","जून","जुलाई","अगस्त","सितंबर","अक्टूबर","नवंबर","दिसंबर"]
  }
};

let currentLang = localStorage.getItem('knit_lang') || 'en';

function t(key) {
  return (translations[currentLang] && translations[currentLang][key]) || translations['en'][key] || key;
}

function setLanguage(lang) {
  currentLang = lang;
  localStorage.setItem('knit_lang', lang);
  document.documentElement.lang = lang === 'hi' ? 'hi' : 'en';
  
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      el.placeholder = t(key);
    } else {
      el.textContent = t(key);
    }
  });
  
  document.querySelectorAll('[data-i18n-html]').forEach(el => {
    el.innerHTML = t(el.getAttribute('data-i18n-html'));
  });
  
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === lang);
  });
}
