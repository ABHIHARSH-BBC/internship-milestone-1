// Firebase Configuration
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase
let db, auth;
let currentUser = null;
let currentUserData = null;

function initFirebase() {
  try {
    if (typeof firebase !== 'undefined') {
      firebase.initializeApp(firebaseConfig);
      db = firebase.firestore();
      auth = firebase.auth();
      
      auth.onAuthStateChanged(user => {
        currentUser = user;
        if (user) {
          loadUserData(user.uid);
        } else {
          currentUserData = null;
          updateNavAuth(false);
        }
      });
    }
  } catch(e) {
    console.log('Firebase not configured, using local mode');
    useLocalMode();
  }
}

// Local Storage Mode (when Firebase is not configured)
let localDB = JSON.parse(localStorage.getItem('knit_db') || '{"users":[],"complaints":[]}');

function saveLocalDB() {
  localStorage.setItem('knit_db', JSON.stringify(localDB));
}

// Reset complaints to zero
function resetComplaints() {
  localDB.complaints = [];
  saveLocalDB();
}

function useLocalMode() {
  const savedUser = localStorage.getItem('knit_current_user');
  if (savedUser) {
    currentUser = JSON.parse(savedUser);
    currentUserData = localDB.users.find(u => u.uid === currentUser.uid);
    updateNavAuth(true);
    if (typeof loadDashboard === 'function') loadDashboard();
  }
}

// Auth Functions
async function registerUser(userData) {
  if (db && auth) {
    const cred = await auth.createUserWithEmailAndPassword(userData.email, userData.password);
    await db.collection('users').doc(cred.user.uid).set({
      ...userData,
      uid: cred.user.uid,
      password: undefined,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    currentUser = cred.user;
    currentUserData = { ...userData, uid: cred.user.uid };
    return { success: true };
  } else {
    if (localDB.users.find(u => u.email === userData.email)) {
      return { success: false, error: 'Email already registered' };
    }
    const uid = 'local_' + Date.now();
    const user = { ...userData, uid, createdAt: new Date().toISOString() };
    localDB.users.push(user);
    saveLocalDB();
    currentUser = { uid, email: userData.email };
    currentUserData = user;
    localStorage.setItem('knit_current_user', JSON.stringify(currentUser));
    return { success: true };
  }
}

async function loginUser(email, password) {
  if (db && auth) {
    const cred = await auth.signInWithEmailAndPassword(email, password);
    currentUser = cred.user;
    return { success: true };
  } else {
    const user = localDB.users.find(u => u.email === email && u.password === password);
    if (!user) return { success: false, error: 'Invalid email or password' };
    currentUser = { uid: user.uid, email: user.email };
    currentUserData = user;
    localStorage.setItem('knit_current_user', JSON.stringify(currentUser));
    return { success: true };
  }
}

async function logoutUser() {
  if (db && auth) {
    await auth.signOut();
  }
  currentUser = null;
  currentUserData = null;
  localStorage.removeItem('knit_current_user');
  window.location.href = 'index.html';
}

function loadUserData(uid) {
  if (db) {
    db.collection('users').doc(uid).get().then(doc => {
      if (doc.exists) {
        currentUserData = doc.data();
        updateNavAuth(true);
        if (typeof loadDashboard === 'function') loadDashboard();
      }
    });
  } else {
    currentUserData = localDB.users.find(u => u.uid === uid);
    updateNavAuth(true);
    if (typeof loadDashboard === 'function') loadDashboard();
  }
}

function updateNavAuth(isLoggedIn) {
  const authNav = document.getElementById('authNav');
  const userNav = document.getElementById('userNav');
  if (authNav && userNav) {
    authNav.style.display = isLoggedIn ? 'none' : 'flex';
    userNav.style.display = isLoggedIn ? 'flex' : 'none';
    if (isLoggedIn && currentUserData) {
      const nameEl = document.getElementById('userDisplayName');
      if (nameEl) nameEl.textContent = currentUserData.fullName || currentUserData.email;
    }
  }
}

// Complaint Functions
async function submitComplaint(complaintData) {
  const complaint = {
    ...complaintData,
    userId: currentUser ? currentUser.uid : 'anonymous',
    userName: currentUserData ? currentUserData.fullName : 'Anonymous',
    userRole: currentUserData ? currentUserData.role : 'student',
    status: 'pending',
    createdAt: new Date().toISOString(),
    id: 'comp_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5)
  };

  if (db) {
    await db.collection('complaints').doc(complaint.id).set(complaint);
  } else {
    localDB.complaints.push(complaint);
    saveLocalDB();
  }
  
  return { success: true, complaint };
}

async function getComplaints(filters = {}) {
  if (db) {
    let query = db.collection('complaints');
    if (filters.userId) query = query.where('userId', '==', filters.userId);
    if (filters.status) query = query.where('status', '==', filters.status);
    if (filters.category) query = query.where('category', '==', filters.category);
    query = query.orderBy('createdAt', 'desc');
    const snapshot = await query.get();
    return snapshot.docs.map(doc => doc.data());
  } else {
    let complaints = [...localDB.complaints];
    if (filters.userId) complaints = complaints.filter(c => c.userId === filters.userId);
    if (filters.status) complaints = complaints.filter(c => c.status === filters.status);
    if (filters.category) complaints = complaints.filter(c => c.category === filters.category);
    return complaints.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }
}

async function getAllComplaints() {
  if (db) {
    const snapshot = await db.collection('complaints').orderBy('createdAt', 'desc').get();
    return snapshot.docs.map(doc => doc.data());
  } else {
    return [...localDB.complaints].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }
}

async function updateComplaintStatus(complaintId, status, note = '') {
  if (db) {
    await db.collection('complaints').doc(complaintId).update({
      status,
      note,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
  } else {
    const idx = localDB.complaints.findIndex(c => c.id === complaintId);
    if (idx !== -1) {
      localDB.complaints[idx].status = status;
      localDB.complaints[idx].note = note;
      localDB.complaints[idx].updatedAt = new Date().toISOString();
      saveLocalDB();
    }
  }
  return { success: true };
}

// Image Upload Functions
let currentImageData = null;

function handleImagePreview(e) {
  const file = e.target.files[0];
  if (!file) return;
  
  if (file.size > 2 * 1024 * 1024) {
    showToast('Image must be under 2MB', 'error');
    return;
  }
  
  if (!file.type.startsWith('image/')) {
    showToast('Please upload an image file', 'error');
    return;
  }
  
  const reader = new FileReader();
  reader.onload = function(ev) {
    currentImageData = ev.target.result;
    document.getElementById('previewImg').src = currentImageData;
    document.getElementById('uploadPlaceholder').style.display = 'none';
    document.getElementById('uploadPreview').style.display = 'flex';
  };
  reader.readAsDataURL(file);
}

function removeImage(e) {
  e.stopPropagation();
  currentImageData = null;
  document.getElementById('compImage').value = '';
  document.getElementById('previewImg').src = '';
  document.getElementById('uploadPlaceholder').style.display = 'flex';
  document.getElementById('uploadPreview').style.display = 'none';
}

// UI Functions
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  
  const icons = { success: '✓', error: '✕', info: 'ℹ' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${icons[type]}</span>
    <span class="toast-message">${message}</span>
  `;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}

function formatDate(dateStr) {
  if (!dateStr) return '-';
  const d = new Date(dateStr);
  const lang = currentLang || 'en';
  const months = translations[lang].months;
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

function formatDateTime(dateStr) {
  if (!dateStr) return '-';
  const d = new Date(dateStr);
  const lang = currentLang || 'en';
  const months = translations[lang].months;
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}, ${d.getHours().toString().padStart(2,'0')}:${d.getMinutes().toString().padStart(2,'0')}`;
}

// Background Particles
function createParticles() {
  const bg = document.querySelector('.bg-animation');
  if (!bg) return;
  
  for (let i = 0; i < 40; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.left = Math.random() * 100 + '%';
    p.style.width = p.style.height = (Math.random() * 4 + 2) + 'px';
    p.style.animationDuration = (Math.random() * 15 + 10) + 's';
    p.style.animationDelay = (Math.random() * 10) + 's';
    p.style.opacity = Math.random() * 0.5 + 0.1;
    bg.appendChild(p);
  }
}

// Scroll Effects
function initScrollEffects() {
  window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (navbar) {
      navbar.classList.toggle('scrolled', window.scrollY > 50);
    }
    
    const scrollTop = document.querySelector('.scroll-top');
    if (scrollTop) {
      scrollTop.classList.toggle('visible', window.scrollY > 400);
    }
    
    document.querySelectorAll('.reveal').forEach(el => {
      const top = el.getBoundingClientRect().top;
      if (top < window.innerHeight - 100) {
        el.classList.add('active');
      }
    });
  });
}

// Mobile Nav
function initMobileNav() {
  const hamburger = document.querySelector('.hamburger');
  const navLinks = document.querySelector('.nav-links');
  if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('active');
      navLinks.classList.toggle('active');
    });
    
    navLinks.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navLinks.classList.remove('active');
      });
    });
  }
}

// Modal Functions
function openModal(id) {
  const modal = document.getElementById(id);
  if (modal) {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) {
    modal.classList.remove('active');
    document.body.style.overflow = '';
  }
}

function switchModal(fromId, toId) {
  closeModal(fromId);
  setTimeout(() => openModal(toId), 200);
}

// Form Handlers
function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  
  if (!email || !password) {
    showToast('Please fill all fields', 'error');
    return;
  }
  
  loginUser(email, password).then(result => {
    if (result.success) {
      showToast('Login successful!', 'success');
      closeModal('loginModal');
      setTimeout(() => {
        if (currentUserData && currentUserData.role === 'director') {
          window.location.href = 'dashboard.html?role=director';
        } else if (currentUserData && currentUserData.role === 'faculty') {
          window.location.href = 'dashboard.html?role=faculty';
        } else {
          window.location.href = 'dashboard.html?role=student';
        }
      }, 500);
    } else {
      showToast(result.error || 'Login failed', 'error');
    }
  });
}

function handleRegister(e) {
  e.preventDefault();
  
  const role = document.querySelector('.role-option.selected')?.dataset.role;
  if (!role) {
    showToast('Please select a role', 'error');
    return;
  }
  
  const password = document.getElementById('regPassword').value;
  const confirmPassword = document.getElementById('regConfirmPassword').value;
  
  if (password !== confirmPassword) {
    showToast('Passwords do not match', 'error');
    return;
  }
  
  if (password.length < 6) {
    showToast('Password must be at least 6 characters', 'error');
    return;
  }
  
  const userData = {
    email: document.getElementById('regEmail').value,
    password: password,
    fullName: document.getElementById('regFullName').value,
    phone: document.getElementById('regPhone').value,
    rollNumber: document.getElementById('regRoll').value,
    department: document.getElementById('regDept').value,
    year: document.getElementById('regYear')?.value || '',
    hostel: document.getElementById('regHostel')?.value || '',
    role: role
  };
  
  if (!userData.email || !userData.fullName || !userData.phone) {
    showToast('Please fill all required fields', 'error');
    return;
  }
  
  registerUser(userData).then(result => {
    if (result.success) {
      showToast('Registration successful!', 'success');
      closeModal('registerModal');
      setTimeout(() => {
        window.location.href = `dashboard.html?role=${role}`;
      }, 500);
    } else {
      showToast(result.error || 'Registration failed', 'error');
    }
  });
}

// Role selector
function initRoleSelector() {
  document.querySelectorAll('.role-option').forEach(opt => {
    opt.addEventListener('click', () => {
      document.querySelectorAll('.role-option').forEach(o => o.classList.remove('selected'));
      opt.classList.add('selected');
      
      const hostelGroup = document.getElementById('hostelGroup');
      const yearGroup = document.getElementById('yearGroup');
      if (opt.dataset.role === 'student') {
        if (hostelGroup) hostelGroup.style.display = 'block';
        if (yearGroup) yearGroup.style.display = 'block';
      } else {
        if (hostelGroup) hostelGroup.style.display = 'none';
        if (yearGroup) yearGroup.style.display = 'none';
      }
    });
  });
}

// Counter Animation
function animateCounter(el, target, duration = 2000) {
  let start = 0;
  const step = timestamp => {
    if (!start) start = timestamp;
    const progress = Math.min((timestamp - start) / duration, 1);
    el.textContent = Math.floor(progress * target);
    if (progress < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

// Init
document.addEventListener('DOMContentLoaded', () => {
  createParticles();
  initScrollEffects();
  initMobileNav();
  initRoleSelector();
  initImageUpload();
  setLanguage(currentLang);
  
  if (typeof initFirebase === 'function') initFirebase();
});

// Image Upload Drag & Drop
function initImageUpload() {
  const area = document.getElementById('imageUploadArea');
  if (!area) return;
  
  ['dragenter', 'dragover'].forEach(evt => {
    area.addEventListener(evt, e => {
      e.preventDefault();
      area.style.borderColor = 'var(--accent)';
      area.style.background = 'rgba(0,191,165,0.05)';
    });
  });
  
  ['dragleave', 'drop'].forEach(evt => {
    area.addEventListener(evt, e => {
      e.preventDefault();
      area.style.borderColor = '';
      area.style.background = '';
    });
  });
  
  area.addEventListener('drop', e => {
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      const input = document.getElementById('compImage');
      const dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;
      input.dispatchEvent(new Event('change'));
    }
  });
}
